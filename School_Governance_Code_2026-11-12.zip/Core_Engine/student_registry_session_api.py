# سجل طلاب المدرسة للعرض والطباعة. المصدر الملف المحفوظ ثم حالة القيد من نور.

from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Header, HTTPException

from .database import connect

router = APIRouter(tags=["session-student-registry"])

_REGISTRY = Path(__file__).resolve().parent / "database" / "students_registry.json"


def _token(value: str) -> str:
    return str(value or "").strip()


def _require_user(x_session_token: str) -> dict:
    from .access import require_user

    try:
        return require_user(_token(x_session_token))
    except PermissionError as error:
        raise HTTPException(status_code=401, detail=str(error)) from error


def _year() -> str:
    try:
        from .teacher_deliverables_api import stored_academic_year

        return stored_academic_year() or "1448-1449"
    except Exception:
        return "1448-1449"


def _status_map(connection) -> dict[str, str]:
    rows = connection.execute(
        """
        SELECT national_id, status FROM noor_students
        WHERE COALESCE(is_deleted, 0) = 0
        """
    ).fetchall()
    return {str(row[0] or "").strip(): str(row[1] or "").strip() for row in rows if row[0]}


def _hidden_students(connection) -> set[str]:
    rows = connection.execute(
        "SELECT national_id FROM noor_students WHERE COALESCE(is_deleted, 0) = 1"
    ).fetchall()
    return {str(row[0] or "").strip() for row in rows if row[0]}


@router.get("/api/session/student-registry")
def list_student_registry(x_session_token: str = Header(default="")):
    """يعيد طلاب السجل المحفوظ. لا حقل جنسية."""
    _require_user(x_session_token)
    if not _REGISTRY.is_file():
        return {"year": _year(), "count": 0, "students": []}
    payload = json.loads(_REGISTRY.read_text(encoding="utf-8"))
    raw = payload.get("students") if isinstance(payload, dict) else payload
    if not isinstance(raw, list):
        raw = []
    connection = connect()
    try:
        statuses = _status_map(connection)
        hidden = _hidden_students(connection)
    finally:
        connection.close()
    students = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        ident = str(item.get("student_nid") or item.get("national_id") or "").strip()
        name = str(item.get("student_name") or item.get("name") or "").strip()
        if not name or ident in hidden:
            continue
        students.append(
            {
                "national_id": ident,
                "name": name,
                "grade": str(item.get("grade") or "").strip(),
                "section": str(item.get("section") or item.get("classroom") or "").strip(),
                "status": statuses.get(ident, ""),
            }
        )
    return {"year": _year(), "count": len(students), "students": students}
