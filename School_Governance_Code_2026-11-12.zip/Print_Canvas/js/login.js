var staffDirectory = [];
var pendingPerson = null;

(function () {
    var params = new URLSearchParams(window.location.search);
    if (params.get("reason") === "expired") {
        var node = document.getElementById("login-message");
        if (node) {
            node.textContent = "انتهت الجلسة، يرجى تسجيل الدخول";
        }
    }
})();

function cleanId(value) {
    return String(value || "").replace(/\D/g, "");
}

function enterSession(person, role) {
    sessionStorage.setItem("sessionUser", JSON.stringify({
        id: person.id,
        name: person.name,
        role: role,
        roles: person.roles,
        token: person.token || ""
    }));
    window.location.href = "dashboard.html";
}

function findPerson() {
    var typed = cleanId(document.getElementById("national-id").value);
    var picked = document.getElementById("staff-search").value;
    var id = typed || picked;
    return staffDirectory.find(function (person) {
        return person.id && person.id === id;
    }) || null;
}

function showRoles(person) {
    pendingPerson = person;
    var panel = document.getElementById("role-choice");
    var actions = document.getElementById("role-choice-actions");
    document.getElementById("role-choice-name").textContent = person.name;
    actions.innerHTML = "";
    person.roles.forEach(function (role) {
        var button = document.createElement("button");
        button.type = "button";
        button.className = "btn-unified-primary";
        button.textContent = "دخول كـ: " + role;
        button.addEventListener("click", function () {
            enterSession(person, role);
        });
        actions.appendChild(button);
    });
    panel.hidden = false;
}

document.getElementById("staff-search").addEventListener("change", function () {
    if (this.value) {
        document.getElementById("national-id").value = this.value;
    }
});

document.getElementById("login-form").addEventListener("submit", function (event) {
    event.preventDefault();
    var message = document.getElementById("login-message");
    var identity = cleanId(document.getElementById("national-id").value) || document.getElementById("staff-search").value;
    var password = document.getElementById("password").value;
    document.getElementById("role-choice").hidden = true;
    if (!identity || !password) {
        message.textContent = "رقم السجل المدني وكلمة المرور مطلوبان.";
        return;
    }
    message.textContent = "";
    fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ national_id: identity, password: password })
    }).then(function (response) {
        return response.json().then(function (payload) {
            if (!response.ok) {
                throw new Error(payload.detail || "تعذر الدخول");
            }
            return payload;
        });
    }).then(function (user) {
        var person = {
            id: user.id,
            name: user.name,
            roles: user.roles && user.roles.length ? user.roles : [user.role || "منسوب"],
            token: user.token
        };
        if (person.roles.length <= 1) {
            enterSession(person, person.roles[0] || "منسوب");
            return;
        }
        showRoles(person);
    }).catch(function (error) {
        message.textContent = error.message || "تعذر الدخول";
    });
});

fetch("/api/staff-directory")
    .then(function (response) {
        if (!response.ok) {
            throw new Error("تعذر قراءة كشف الكادر");
        }
        return response.json();
    })
    .then(function (payload) {
        staffDirectory = payload.people || [];
        var search = document.getElementById("staff-search");
        staffDirectory.forEach(function (person) {
            if (!person.id || !person.name) {
                return;
            }
            var option = document.createElement("option");
            option.value = person.id;
            option.textContent = person.name;
            search.appendChild(option);
        });
    })
    .catch(function (error) {
        document.getElementById("login-message").textContent = error.message;
    });

fetch("/api/trial-launch", { cache: "no-store" })
    .then(function (response) {
        return response.ok ? response.json() : null;
    })
    .then(function (trial) {
        var banner = document.getElementById("trial-banner");
        if (!banner || !trial || !trial.enabled) {
            return;
        }
        banner.hidden = false;
        banner.textContent =
            "وضع التجربة مفعّل · ابحث عن اسمك أو اكتب رقم السجل · كلمة المرور: " +
            (trial.password || "");
        var password = document.getElementById("password");
        if (password && trial.password && !password.value) {
            password.placeholder = trial.password;
        }
    })
    .catch(function () {});

(function () {
    var splash = document.getElementById("opening-splash");
    var slides = Array.prototype.slice.call(document.querySelectorAll(".opening-slide"));
    var dots = Array.prototype.slice.call(document.querySelectorAll(".opening-dot"));
    var index = 0;
    var timer = 0;

    function show(next) {
        if (!slides.length) {
            return;
        }
        index = (next + slides.length) % slides.length;
        slides.forEach(function (slide, item) {
            slide.classList.toggle("is-active", item === index);
        });
        dots.forEach(function (dot, item) {
            dot.classList.toggle("is-active", item === index);
        });
    }

    function arm() {
        window.clearInterval(timer);
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
            return;
        }
        timer = window.setInterval(function () {
            show(index + 1);
        }, 7000);
    }

    if (splash) {
        var closeSplash = function () {
            splash.classList.add("is-gone");
            window.setTimeout(function () {
                splash.hidden = true;
            }, 480);
        };
        splash.addEventListener("click", closeSplash);
        var delay = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 200 : 1700;
        window.setTimeout(closeSplash, delay);
    }

    Array.prototype.forEach.call(document.querySelectorAll("[data-slide]"), function (button) {
        button.addEventListener("click", function () {
            show(index + Number(button.getAttribute("data-slide")));
            arm();
        });
    });
    dots.forEach(function (dot, item) {
        dot.addEventListener("click", function () {
            show(item);
            arm();
        });
    });
    show(0);
    arm();
})();
