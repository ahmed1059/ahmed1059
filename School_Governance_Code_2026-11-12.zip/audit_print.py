# فحص مسارات الطباعة. يفتح الشاشات ويلتقط المعاينة، ولا يكتب بيانات المدرسة.
# جلسة الدخول صف في auth_sessions فقط، حتى تُفتح الشاشات المحمية.

from __future__ import annotations

import json
import sqlite3
import sys
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
BASE = "http://127.0.0.1:8060"
DB_PATH = ROOT / "School_Data" / "school_1059.db"
OUT_DIR = ROOT / "audit_screenshots"
HEADER = "المملكة العربية السعودية"
SIGNOFF = "اعتماد"


def principal_id() -> str:
    connection = sqlite3.connect(DB_PATH)
    try:
        row = connection.execute(
            """
            SELECT national_id FROM users
            WHERE COALESCE(is_active, 1) = 1
              AND role LIKE 'مدير%'
              AND TRIM(COALESCE(national_id, '')) != ''
            LIMIT 1
            """
        ).fetchone()
    finally:
        connection.close()
    if not row or not str(row[0]).strip():
        raise SystemExit("لا حساب مدير لقراءة الشاشات.")
    return str(row[0]).strip()


def http_json(url: str, payload: dict | None = None) -> dict:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def login_payload() -> dict:
    trial = http_json(BASE + "/api/trial-launch")
    if not trial.get("enabled") or not str(trial.get("password") or "").strip():
        raise SystemExit("وضع التجربة مغلق، ولا تُخزَّن كلمة مرور داخل السكربت.")
    body = http_json(
        BASE + "/api/login",
        {"national_id": principal_id(), "password": str(trial["password"])},
    )
    if not body.get("token"):
        raise SystemExit("الدخول لم يعد رمزاً للجلسة.")
    return body


def first_program_id() -> str:
    payload = http_json(BASE + "/api/programs")
    programs = payload.get("programs") if isinstance(payload, dict) else []
    for item in programs or []:
        if isinstance(item, dict) and item.get("id"):
            return str(item["id"])
    return ""


def first_council_id() -> str:
    payload = http_json(BASE + "/api/councils")
    minutes = payload.get("minutes") if isinstance(payload, dict) else []
    for item in minutes or []:
        if isinstance(item, dict) and str(item.get("id") or "").strip():
            return str(item["id"]).strip()
    return ""


def routes() -> list[dict]:
    program_id = first_program_id()
    council_id = first_council_id()
    items = [
        {
            "name": "سجل الطلاب",
            "file": "students",
            "hash": "view-student-registry",
            "button": "#aj-sr-print",
            "ready": "#aj-sr-status",
        },
        {
            "name": "المنسوبون",
            "file": "staff",
            "hash": "view-staff",
            "button": "#aj-staff-print",
            "ready": "#aj-staff-status",
        },
        {
            "name": "اللجان",
            "file": "committees",
            "hash": "view-council-details?id=" + council_id if council_id else "view-committees",
            "button": "#aj-council-print" if council_id else "",
            "ready": "#view-council-details, #view-committees",
            "blocked": "" if council_id else "لا محضر محفوظ، وزر اعتماد التشكيل يكتب بيانات فلم يُضغط",
        },
        {
            "name": "بطاقة البرنامج",
            "file": "program-card",
            "hash": "view-plan-details?id=" + program_id if program_id else "view-planning",
            "button": "#aj-plan-print" if program_id else "",
            "ready": "#aj-plan-print, #aj-plan-detail-error",
            "blocked": "" if program_id else "لا برنامج محفوظ لفتح بطاقته",
        },
        {
            "name": "الخطط",
            "file": "plans",
            "hash": "view-plan-details?id=operational-plan",
            "button": "#aj-plan-print",
            "ready": "#aj-plan-print",
        },
    ]
    return items


def judge(html: str, opened: bool) -> tuple[bool, str]:
    if not opened:
        return False, "لم تُفتح المعاينة"
    has_header = HEADER in html
    has_signoff = SIGNOFF in html
    has_core = 'class="pm-document' in html or "pm-document" in html
    if has_header and has_signoff and has_core:
        return True, ""
    if has_header and has_signoff and not has_core:
        return False, "الترويسة والاعتماد ظاهران دون PrintMasterCore"
    missing = []
    if not has_header:
        missing.append("لا ترويسة")
    if not has_signoff:
        missing.append("لا اعتماد")
    if not has_core:
        missing.append("لا PrintMasterCore")
    return False, "، ".join(missing)


def open_route(page, item: dict) -> tuple[bool, str]:
    if item.get("blocked"):
        page.goto(BASE + "/app-journey.html#" + item["hash"], wait_until="domcontentloaded")
        page.wait_for_timeout(1200)
        page.screenshot(path=str(OUT_DIR / (item["file"] + ".png")), full_page=True)
        return False, item["blocked"]
    page.goto(BASE + "/app-journey.html#" + item["hash"], wait_until="domcontentloaded")
    button = page.locator(item["button"])
    button.wait_for(state="attached", timeout=20000)
    page.wait_for_function(
        """(selector) => {
            const node = document.querySelector(selector);
            return node && !node.hidden && !node.disabled;
        }""",
        arg=item["button"],
        timeout=25000,
    )
    button.click()
    opened = False
    try:
        page.wait_for_selector("#aj-print-stage:not([hidden]) #aj-print-stage-page", timeout=25000)
        opened = True
    except Exception:
        opened = False
    page.wait_for_timeout(800)
    html = ""
    if opened:
        html = page.locator("#aj-print-stage-page").inner_html()
    page.screenshot(path=str(OUT_DIR / (item["file"] + ".png")), full_page=True)
    close = page.locator("#aj-print-preview-close")
    if close.count() and close.is_visible():
        close.click()
        page.wait_for_timeout(300)
    return judge(html, opened)


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    user = login_payload()
    stored = {
        "id": user.get("id") or "",
        "name": user.get("name") or "",
        "role": user.get("role") or "",
        "roles": user.get("roles") or [],
        "token": user.get("token") or "",
    }
    lines = []
    failed = 0
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        context = browser.new_context(viewport={"width": 1440, "height": 900}, locale="ar-SA")
        context.add_init_script("window.print = function () {};")
        page = context.new_page()
        page.goto(BASE + "/login.html", wait_until="domcontentloaded")
        page.evaluate("(user) => sessionStorage.setItem('sessionUser', JSON.stringify(user))", stored)
        for item in routes():
            try:
                ok, reason = open_route(page, item)
            except Exception as error:
                ok = False
                reason = str(error).splitlines()[0][:180] or "تعذر فتح المسار"
                shot = OUT_DIR / (item["file"] + ".png")
                if not shot.is_file():
                    try:
                        page.screenshot(path=str(shot), full_page=True)
                    except Exception:
                        pass
            if ok:
                line = "المسار " + item["name"] + ": ✅ ناجح"
            else:
                failed += 1
                line = "المسار " + item["name"] + ": ❌ فاشل (" + reason + ")"
            print(line)
            lines.append(line)
        browser.close()
    report = OUT_DIR / "report.txt"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
